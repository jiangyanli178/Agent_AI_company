#!/usr/bin/env bash
# 一键部署。在服务器上执行：bash deploy.sh
set -e

echo "=== 1/4 检查 Docker ==="
if ! command -v docker >/dev/null 2>&1; then
  echo "没装 Docker，开始安装（约 2 分钟）…"
  if command -v apt-get >/dev/null 2>&1; then
    curl -fsSL https://get.docker.com | bash -s docker --mirror Aliyun
  elif command -v yum >/dev/null 2>&1; then
    curl -fsSL https://get.docker.com | bash -s docker --mirror Aliyun
  else
    echo "系统太老，请手动装 Docker：https://docs.docker.com/engine/install/"
    exit 1
  fi
fi
docker --version

echo "=== 2/4 构建镜像 ==="
docker compose build || docker-compose build

echo "=== 3/4 先跑一次，确认能拿到数据 ==="
docker compose run --rm strategy

echo "=== 4/4 加每日定时（每个交易日 18:10）==="
CRON_LINE="10 18 * * 1-5 cd $(pwd) && docker compose up -d --build >> cron.log 2>&1"
( crontab -l 2>/dev/null | grep -v "jragent-strategy" ; echo "# jragent-strategy" ; echo "$CRON_LINE" ) | crontab -

echo
echo "部署完成。"
echo "  看信号：cat data/signals.json"
echo "  看日志：docker compose logs -f"
echo "  改参数：编辑 .env 后 docker compose up -d --build"
