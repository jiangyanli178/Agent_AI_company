# -*- coding: utf-8 -*-
"""
5/20 均线金叉 · 由「全域策略研究所」导出

用法：
    pip install akshare pandas
    python strategy.py --symbol 600519 --years 3

说明：
    - 数据用 akshare 前复权日线（qfq），和你在线上的回测是同一份口径
    - 信号 T 日产生、T+1 成交，不含未来函数
    - 涨停日不可买入，会被拦截并计数
    - 本脚本只做历史回测，不接实盘、不下单
"""

import argparse
import sys

import pandas as pd


# ============================================================
# 策略定义（参数来自你在网站上的设置）
# ============================================================
PARAMS = {'fast': 5, 'slow': 20}

# 额外过滤条件（网站上的设置）：
# （本策略没有额外的过滤条件）



def gen_signal(df, p):
    """均线交叉：快线上穿慢线买入，下穿卖出"""
    fast = df["close"].rolling(int(p["fast"])).mean()
    slow = df["close"].rolling(int(p["slow"])).mean()
    sig = pd.Series(0, index=df.index)
    sig[fast > slow] = 1
    sig[fast.isna() | slow.isna()] = 0
    return sig


def gen_filter_ok(df):
    """返回「今天是否允许买入」的布尔序列。返回 None 表示没有过滤条件。"""
    ok = pd.Series(True, index=df.index)
    used = False

    return ok if used else None


# ============================================================
# 回测
# ============================================================
def load_bars(symbol: str, years: int) -> pd.DataFrame:
    import akshare as ak
    from datetime import date, timedelta

    end = date.today().strftime("%Y%m%d")
    start = (date.today() - timedelta(days=365 * years + 30)).strftime("%Y%m%d")
    df = ak.stock_zh_a_hist(symbol=symbol, period="daily",
                            start_date=start, end_date=end, adjust="qfq")
    if df is None or df.empty:
        sys.exit(f"没拿到 {symbol} 的数据，检查代码或网络")
    df = df.rename(columns={"日期": "date", "开盘": "open", "收盘": "close",
                             "最高": "high", "最低": "low", "成交量": "volume"})
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values("date").reset_index(drop=True)


def run(df: pd.DataFrame, fee_rate: float = 0.0010, limit_pct: float = 0.10):
    sig = gen_signal(df, PARAMS)
    filt = gen_filter_ok(df)

    n = len(df)
    equity, curve = 1.0, [1.0]
    pos_prev, blocked, trades = 0, 0, []
    entry = None

    for i in range(1, n):
        pos = int(sig.iloc[i - 1])          # T 日信号，T+1 生效
        ret = df["close"].iloc[i] / df["close"].iloc[i - 1] - 1

        # 涨停不买、跌停不卖
        if pos == 1 and pos_prev == 0 and ret >= limit_pct:
            pos, blocked = pos_prev, blocked + 1
        elif pos == 0 and pos_prev == 1 and ret <= -limit_pct:
            pos, blocked = pos_prev, blocked + 1

        # 过滤条件只限制买入
        if pos == 1 and pos_prev == 0 and filt is not None and not bool(filt.iloc[i]):
            pos = 0

        cost = abs(pos - pos_prev) * fee_rate
        equity *= (1 + pos * ret - cost)
        curve.append(equity)

        if pos != pos_prev:
            if pos == 1:
                entry = df["close"].iloc[i]
            elif entry is not None:
                trades.append(df["close"].iloc[i] / entry - 1 - 2 * fee_rate)
                entry = None
        pos_prev = pos

    peak, mdd = 0.0, 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = max(mdd, (peak - v) / peak if peak else 0)

    bench = df["close"].iloc[-1] / df["close"].iloc[0] - 1
    wins = sum(1 for t in trades if t > 0)
    return {
        "total_return": curve[-1] - 1,
        "max_drawdown": mdd,
        "benchmark": bench,
        "trades": len(trades),
        "win_rate": (wins / len(trades)) if trades else 0.0,
        "blocked": blocked,
        "days": n,
    }


def main():
    ap = argparse.ArgumentParser(description="5/20 均线金叉 回测脚本")
    ap.add_argument("--symbol", default="600519")
    ap.add_argument("--years", type=int, default=3)
    args = ap.parse_args()

    print(f"正在拉取 {args.symbol} 近 {args.years} 年数据…")
    df = load_bars(args.symbol, args.years)
    r = run(df)

    print()
    print("=" * 52)
    print(f"  {args.symbol}  共 {r['days']} 个交易日")
    print("=" * 52)
    print(f"  策略收益    {r['total_return']*100:>8.2f}%")
    print(f"  买入持有    {r['benchmark']*100:>8.2f}%")
    print(f"  超额收益    {(r['total_return']-r['benchmark'])*100:>8.2f}%")
    print(f"  最大回撤   -{r['max_drawdown']*100:>8.2f}%")
    print(f"  交易次数   {r['trades']:>9}")
    print(f"  胜率        {r['win_rate']*100:>7.1f}%")
    if r["blocked"]:
        print(f"  涨停拦截   {r['blocked']:>9} 次（实盘这部分收益拿不到）")
    print()
    print("  历史表现不代表未来，回测收益通常高于实盘。")


if __name__ == "__main__":
    main()
