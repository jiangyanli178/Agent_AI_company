# -*- coding: utf-8 -*-
"""
每日信号任务 —— 模板文件，不需要改。

做的事：
  1. 拉最近 N 年日线
  2. 用 strategy.py 里定义的参数算信号
  3. 把「今天该买还是该卖」写进 signals.json，并打印出来

设计上有意做成「只出信号、不下单」：
任何自动下单都需要先确认券商的接口权限和风控规则，
本模板不碰钱，避免因为程序 bug 造成真实损失。
"""
import json
import os
import sys
from datetime import datetime

from strategy import load_bars, PARAMS, gen_signal, gen_filter_ok

SYMBOL = os.environ.get("SYMBOL", "600519")
YEARS = int(os.environ.get("YEARS", "3"))
OUT = os.environ.get("OUT_FILE", "signals.json")


def main():
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] 拉取 {SYMBOL} 数据…")
    df = load_bars(SYMBOL, YEARS)
    if df is None or len(df) < 60:
        print("数据不足，跳过")
        sys.exit(1)

    df["sig"] = gen_signal(df, PARAMS)
    df["ok"] = gen_filter_ok(df)

    last = df.iloc[-1]
    prev = df.iloc[-2]

    raw = int(last["sig"])
    raw_prev = int(prev["sig"])
    allowed = bool(last["ok"])

    if raw == 1 and raw_prev == 0 and allowed:
        action = "BUY"
        reason = "出现买入信号，且当前满足全部过滤条件"
    elif raw == 0 and raw_prev == 1:
        action = "SELL"
        reason = "出现卖出信号"
    elif raw == 1 and not allowed:
        action = "HOLD"
        reason = "有买入信号，但被过滤条件挡掉了（不追高/趋势不强）"
    else:
        action = "HOLD"
        reason = "没有新的信号"

    rec = {
        "date": str(last.get("date", ""))[:10],
        "symbol": SYMBOL,
        "action": action,
        "close": round(float(last["close"]), 3),
        "reason": reason,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }

    history = []
    if os.path.exists(OUT):
        try:
            with open(OUT, "r", encoding="utf-8") as f:
                history = json.load(f)
        except Exception:
            history = []
    history.append(rec)
    history = history[-250:]          # 只留最近一年
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

    print(f"  {rec['date']}  {action}  收盘 {rec['close']}")
    print(f"  理由：{reason}")


if __name__ == "__main__":
    main()
